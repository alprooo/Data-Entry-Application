<!DOCTYPE html>
<html lang="en">
<!-- Mirrored from technext.github.io/mazer/auth-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 13 Nov 2021 06:38:38 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login - PPIM</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&amp;display=swap"
        rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('vendors/bootstrap-icons/bootstrap-icons.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/pages/auth.css')); ?>" />

    <?php echo $__env->yieldContent('addStyle'); ?>


</head>

<body>
    
    <?php echo $__env->yieldContent('content'); ?>
</body>

<?php echo $__env->yieldContent('addScript'); ?>

<!-- Mirrored from technext.github.io/mazer/auth-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 13 Nov 2021 06:38:38 GMT -->

</html>
<?php /**PATH C:\DLL\laravel_app\ppim\resources\views/layouts/auth.blade.php ENDPATH**/ ?>