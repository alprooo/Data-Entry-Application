<!DOCTYPE html>
<html lang="en">
<!-- Mirrored from technext.github.io/mazer/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 13 Nov 2021 06:37:23 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>PPIM</title>

    <link rel="preconnect" href="https://fonts.gstatic.com/" />
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&amp;display=swap"
        rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('')); ?>css/bootstrap.css" />

    <link rel="stylesheet" href="<?php echo e(asset('')); ?>vendors/iconly/bold.css" />

    <link rel="stylesheet" href="<?php echo e(asset('')); ?>vendors/perfect-scrollbar/perfect-scrollbar.css" />
    <link rel="stylesheet" href="<?php echo e(asset('')); ?>vendors/bootstrap-icons/bootstrap-icons.css" />
    <link rel="stylesheet" href="<?php echo e(asset('')); ?>css/app.css" />
    <link rel="shortcut icon" href="<?php echo e(asset('')); ?>images/favicon.html" type="image/x-icon" />

    <?php echo $__env->yieldContent('addStyle'); ?>

</head>

<body>
    <div id="app">

        <?php if(Auth::user()->role == 0): ?>
            <?php echo $__env->make('student.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>



        <div id="main">

            <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->yieldContent('content'); ?>

            <footer>
                <div class="footer clearfix mb-0 text-muted">
                    <div class="float-start">
                        <p>2022 &copy; PPIM</p>
                    </div>
                    <div class="float-end">
                        <p>
                            Crafted with
                            <span class="text-danger"><i class="bi bi-heart"></i></span> by
                            <a href="http://ppim.co.id/">PPIM</a>
                        </p>
                    </div>
                </div>
            </footer>
        </div>
    </div>
</body>

<script src="<?php echo e(asset('')); ?>vendors/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<script src="<?php echo e(asset('')); ?>js/bootstrap.bundle.min.js"></script>

<script src="<?php echo e(asset('')); ?>vendors/apexcharts/apexcharts.js"></script>
<script src="<?php echo e(asset('')); ?>js/pages/dashboard.js"></script>

<script src="<?php echo e(asset('')); ?>js/main.js"></script>

<?php echo $__env->yieldContent('addScript'); ?>

<!-- Mirrored from technext.github.io/mazer/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 13 Nov 2021 06:37:55 GMT -->

</html>
<?php /**PATH C:\DLL\laravel_app\ppim\resources\views/layouts/main.blade.php ENDPATH**/ ?>