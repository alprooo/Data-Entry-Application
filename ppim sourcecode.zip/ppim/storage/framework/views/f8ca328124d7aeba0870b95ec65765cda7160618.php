

<?php $__env->startSection('addStyle'); ?>
    <link href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap4.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <section class="row">
            <div class="col-12 col-lg-12">

                <div class="card" style="border-radius: 20px">
                    <div class="card-header"
                        style="background-color: #435EBE;border-top-left-radius: 20px;border-top-right-radius: 20px">
                        <h3 class="text-white">List Student Data</h3>
                        <p class="text-subtitle text-white">
                            List data yang sudah anda daftarkan pada form registrasi di aplikasi.
                        </p>

                    </div>
                    <div class="card-body pt-3">

                        <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success alert-dismissible show fade">
                                <?php echo e($message); ?>

                                <button type="button" class="btn-close btn-sm" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                            </div>
                        <?php endif; ?>

                        <table class="table table-striped" id="table1">
                            <thead>
                                <tr>
                                    <th>Student ID</th>
                                    <th>Fullname</th>
                                    <th>Email</th>
                                    <th>Phone Number</th>
                                    <th>Campus</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->student_id); ?></td>
                                        <td><?php echo e($item->fname . ' ' . $item->lname); ?></td>
                                        <td><?php echo e($item->email); ?></td>
                                        <td><?php echo e($item->phone_num); ?></td>
                                        <td><?php echo e($item->campus); ?></td>
                                        <td><?php echo e($item->status); ?></td>
                                        <td>

                                            <a class="btn btn-primary"
                                                href="<?php echo e(route('student.detail', ['id' => $item->id])); ?>">Detail</a>

                                            <a href="<?php echo e(route('student.delete', ['id' => $item->id])); ?>"
                                                class="btn btn-danger">
                                                Delete
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div>

            </div>

        </section>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('addScript'); ?>
    

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
    

    <script>
        $(document).ready(function() {


            // new $.fn.dataTable.FixedHeader(table);

            $('#table1').DataTable({
                dom: 'Bfrtip',
                ordering: false,
                buttons: [{
                    extend: 'excel',
                    text: 'Excel',
                    className: 'btn btn-success text-default',
                    exportOptions: {
                        columns: 'th:not(:last-child)'
                    }
                }, {
                    extend: 'pdf',
                    text: 'PDF',
                    className: 'btn btn-danger text-default',
                    exportOptions: {
                        columns: 'th:not(:last-child)'
                    }
                }, ]
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\DLL\laravel_app\ppim\resources\views/admin/list-student.blade.php ENDPATH**/ ?>